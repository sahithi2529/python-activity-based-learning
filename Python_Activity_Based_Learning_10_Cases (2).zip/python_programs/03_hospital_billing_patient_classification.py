def hospital_bill(age, consultation, diagnostics, treatment):
    subtotal = consultation + diagnostics + treatment
    discount = subtotal * 0.10 if age >= 60 else 0
    final_bill = subtotal - discount
    category = "High" if final_bill > 5000 else "Standard"
    return subtotal, discount, final_bill, category

records = [
    ("Patient 1", 65, 500, 1800, 4000),
    ("Patient 2", 25, 400, 900, 2200),
]
for name, age, consultation, diagnostics, treatment in records:
    subtotal, discount, final_bill, category = hospital_bill(age, consultation, diagnostics, treatment)
    print(f"{name}: subtotal Rs.{subtotal:.2f}, concession Rs.{discount:.2f}, "
          f"final Rs.{final_bill:.2f}, category {category}")
