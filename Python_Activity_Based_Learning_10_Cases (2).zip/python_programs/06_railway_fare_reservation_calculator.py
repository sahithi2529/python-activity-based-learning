def railway_fare(age, distance, travel_class):
    travel_class = travel_class.lower()
    if travel_class == "sleeper":
        rate = 1.5
    elif travel_class == "ac":
        rate = 3.0
    else:
        raise ValueError("Travel class must be Sleeper or AC.")
    fare = distance * rate
    if age < 12:
        fare *= 0.5
    return fare + 40

passengers = [
    ("Meena", 10, 250, "Sleeper"),
    ("Ravi", 20, 250, "AC"),
    ("Sana", 35, 100, "Sleeper"),
]
for name, age, distance, travel_class in passengers:
    total = railway_fare(age, distance, travel_class)
    print(f"{name}: {travel_class}, {distance} km -> Rs.{total:.2f}")
