items = [
    ("Headphones", "electronics", 1500, 1),
    ("Notebook", "books", 100, 6),
    ("Bottle", "other", 250, 2),
]
rates = {"electronics": 0.18, "books": 0.05, "other": 0.12}
subtotal = sum(price * qty for name, category, price, qty in items)
discount = min(subtotal * 0.10, 500) if subtotal > 2000 else 0
discount_rate = discount / subtotal if subtotal else 0
tax = 0

for name, category, price, qty in items:
    line = price * qty
    discounted_line = line * (1 - discount_rate)
    line_tax = discounted_line * rates[category]
    tax += line_tax
    print(f"{name}: subtotal Rs.{line:.2f}, tax Rs.{line_tax:.2f}")

print(f"Subtotal: Rs.{subtotal:.2f}")
print(f"Discount: Rs.{discount:.2f}")
print(f"Tax: Rs.{tax:.2f}")
print(f"Final total: Rs.{subtotal - discount + tax:.2f}")
