plans = [
    ("Plan A", 199, 2, 30),
    ("Plan B", 299, 5, 20),
    ("Plan C", 399, 10, 25),
]
usage_gb = 6
budget = 350
eligible = []

for name, base, included, rate in plans:
    extra_cost = max(0, usage_gb - included) * rate
    total = base + extra_cost
    print(f"{name}: Rs.{total:.2f}")
    if total <= budget:
        eligible.append((total, name))

if eligible:
    cost, name = min(eligible)
    print(f"Best plan within budget: {name} at Rs.{cost:.2f}")
else:
    print("No plan fits the budget.")
