venue = 10000
equipment = 5000
transport = 4000
catering_per_person = 250
certificate_per_person = 30
sponsorship = 12000
registration_fee = 400
participants = 100

fixed_cost = venue + equipment + transport
variable_per_person = catering_per_person + certificate_per_person
total_cost = fixed_cost + participants * variable_per_person
amount_after_sponsorship = total_cost - sponsorship
contribution_per_person = amount_after_sponsorship / participants

net_fixed = fixed_cost - sponsorship
margin_per_registration = registration_fee - variable_per_person
break_even = (net_fixed + margin_per_registration - 1) // margin_per_registration

print(f"Total event cost: Rs.{total_cost:.2f}")
print(f"After sponsorship: Rs.{amount_after_sponsorship:.2f}")
print(f"Required contribution per participant: Rs.{contribution_per_person:.2f}")
print(f"Break-even registrations: {int(break_even)}")
