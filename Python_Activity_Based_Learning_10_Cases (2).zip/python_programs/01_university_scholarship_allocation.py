applicants = [
    ("Asha", 88, 79, 91, 92, 180000),
    ("Bharat", 75, 80, 78, 88, 220000),
    ("Charan", 92, 35, 90, 95, 150000),
    ("Divya", 81, 84, 86, 90, 240000),
]

eligible = []
for name, s1, s2, s3, attendance, income in applicants:
    percentage = (s1 + s2 + s3) / 3
    if min(s1, s2, s3) >= 40 and percentage >= 75 and attendance >= 85 and income <= 250000:
        eligible.append((name, percentage, attendance))

eligible.sort(key=lambda item: (item[1], item[2]), reverse=True)
print("Eligible scholarship applicants:")
for rank, (name, percentage, attendance) in enumerate(eligible, 1):
    print(f"{rank}. {name}: {percentage:.2f}%, attendance {attendance}%")
