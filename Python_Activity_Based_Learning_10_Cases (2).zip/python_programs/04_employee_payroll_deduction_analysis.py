def payroll(basic, allowances, overtime, incentive):
    gross = basic + allowances + overtime + incentive
    if gross <= 20000:
        deduction = gross * 0.05
    else:
        deduction = 20000 * 0.05 + (gross - 20000) * 0.10
    return gross, deduction, gross - deduction

employees = [
    ("Employee A", 18000, 2500, 1000, 500),
    ("Employee B", 15000, 2000, 0, 1000),
]
for name, basic, allowances, overtime, incentive in employees:
    gross, deduction, net = payroll(basic, allowances, overtime, incentive)
    print(f"{name}: gross Rs.{gross:.2f}, deduction Rs.{deduction:.2f}, net Rs.{net:.2f}")
