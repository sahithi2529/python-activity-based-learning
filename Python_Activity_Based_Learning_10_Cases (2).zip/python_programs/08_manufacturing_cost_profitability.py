quantity = 500
material_rate = 40
labour_cost = 6000
machine_cost = 2500
selling_price = 65
target_profit = 5000

material = quantity * material_rate
wastage = material * 0.08
total_cost = material + wastage + labour_cost + machine_cost
revenue = quantity * selling_price
profit = revenue - total_cost

print(f"Material cost: Rs.{material:.2f}")
print(f"Wastage cost: Rs.{wastage:.2f}")
print(f"Total cost: Rs.{total_cost:.2f}")
print(f"Revenue: Rs.{revenue:.2f}")
print(f"Profit: Rs.{profit:.2f}")
print("Target met" if profit >= target_profit else "Target not met")
