def calculate_bill(units):
    if units < 0:
        raise ValueError("Units cannot be negative.")
    if units <= 100:
        energy = units * 2
    elif units <= 200:
        energy = 100 * 2 + (units - 100) * 3
    else:
        energy = 100 * 2 + 100 * 3 + (units - 200) * 5
    surcharge = energy * 0.05 if units > 250 else 0
    return energy + 50 + surcharge

for month, units in enumerate([80, 150, 230, 300], 1):
    print(f"Month {month}: {units} units -> Rs. {calculate_bill(units):.2f}")
