rates = {"USD": 83, "EUR": 90, "GBP": 105}
expenses = [
    ("Hotel", 200, "USD"),
    ("Food", 100, "EUR"),
    ("Transport", 80, "GBP"),
]
budget = 50000
converted_expenses = []

for category, amount, currency in expenses:
    converted = amount * rates[currency]
    final = converted * 1.02
    converted_expenses.append((category, final))
    print(f"{category}: Rs.{final:.2f}")

total = sum(amount for category, amount in converted_expenses)
largest = max(converted_expenses, key=lambda item: item[1])
print(f"Total with fees: Rs.{total:.2f}")
print(f"Largest expense: {largest[0]}")
print("Within budget" if total <= budget else f"Over budget by Rs.{total-budget:.2f}")
