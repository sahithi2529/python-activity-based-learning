# Python Activity-Based Learning Assignment

**Name:** M. Sahithi  
**Roll Number:** 26000951  
**Branch:** CSM  
**Section:** 2  

## Selected Case Studies
1. University Scholarship Allocation
2. Progressive Electricity Billing
3. Hospital Billing and Patient Classification
4. Employee Payroll and Deduction Analysis
5. Multi-Plan Telecommunications Cost Optimization
6. Railway Fare and Reservation Calculator
7. Retail Billing with Multiple Discount Rules
8. Manufacturing Cost and Profitability Analysis
9. Multi-Currency Travel Budget Analysis
10. Campus Event Financial Planning

## Files
- `Python_Assignment_M_Sahithi_26000951.pdf`: the supplied 22-page assignment PDF.
- `python_programs/`: individual Python source files for all 10 case studies.

## Run a program
Use Python 3 and run, for example:
```bash
python python_programs/01_university_scholarship_allocation.py
```

Note: The programs use the sample values shown in the assignment PDF. Review the assignment's test cases and sample outputs before submission.
